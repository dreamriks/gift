<?php
/**
 * @version		1.2 feedback $
 * @copyright	Copyright � 2010 Mertonium. All rights reserved.
 * @license		GNU/GPL
 * @author		Mertonium
 * @author mail	john@mertonium.com
 * @website		http://mertonium.com
 *
 */
 
//no direct access
defined('_JEXEC') or die('Restricted Access'); 

// include the template for display
require(JModuleHelper::getLayoutPath('mod_feedback'));