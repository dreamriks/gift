<?php
defined( '_VALID_MOS' ) or die( 'Direct access to this location is not allowed!' );
?>