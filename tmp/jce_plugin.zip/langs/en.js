// UK lang variables

tinyMCE.addToLang('productsnap',{
desc : 'Insert/Edit Product Snapshot',
missing_selection : 'Please select a product from the list.',
delta_width : 0,
delta_height : 0
});
